import { back2top, loadTooptip, modeWatcher } from '../components';

export function basic() {
  modeWatcher();
  back2top();
  loadTooptip();
}
